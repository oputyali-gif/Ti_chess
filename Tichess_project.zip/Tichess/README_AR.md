# Tichess — تطبيق شطرنج للأندرويد

- رقعة خضراء، وتقدر تغيّر **شكل القطع** من القائمة أعلى الشاشة (مجموعتك الكلاسيك + المجموعة الملكية).
- **العب ضد بوت:** شريط البوتات فوق الرقعة، كل بوت بشكل قطعة وتقييمه تحتها (يتغير حسب المحرك):

| البوت | Sara | Stockfish |
|---|---|---|
| البيدق | 250 | 300 |
| الحصان | 450 | 500 |
| الفيل | 500 | 550 |
| الطابية | 1000 | 1050 |
| الوزيرة | 1500 | 1550 |
| الملك | 2100 | 2150 |
| بلا حدود (MAX) | أقصى قوة، والوقت من القائمة | |

  (الطابية والفروق في عمود Stockfish أرقام مبدئية، وكلها قابلة للتعديل في الملف `app/src/main/assets/bots.js`.)
- **تحليل مباراة** بالأيقونات ‼️ ❗ 👍 📒 ⁉️ ❓ ❓❓ ❌ ➡️، وبعد انتهاء المباراة يسألك: هل تريد مراجعتها؟

## إضافة مجموعة قطع جديدة
1. أنشئ مجلداً `app/src/main/assets/pieces/set3` فيه 12 ملف: `wK wQ wR wB wN wP bK bQ bR bB bN bP` بصيغة `.svg`.
2. في `app/src/main/assets/app.js` أضف سطراً داخل `PIECE_SETS`:
   `{ id: 'set3', name: 'اسم المجموعة', dir: 'pieces/set3' }`

## تحديث التطبيق على GitHub (من Codespaces)
```
python3 -m zipfile -e Tichess_project.zip .
cp -r Tichess/. .
rm -rf Tichess Tichess_project.zip app/src/main/assets/pieces/*.svg
git add -A && git commit -m "Tichess" && git push
```
(ارفع الـ zip أولاً داخل المستكشف.) بعدها يبني GitHub النسخة تلقائياً (Actions) وتنزّلها من Releases.

## ملاحظات
- النسخة `lite` = Sara فقط، و`full` = Sara + Stockfish 19 (حجم كبير بسبب الشبكة العصبية).
- قطع `set1` هي مجموعة cburnett (من Colin M.L. Burnett، ترخيص GPL/BSD/CC).
